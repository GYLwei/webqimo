package cn.enilu.flash.service.message;


import cn.enilu.flash.bean.entity.message.MessageTemplate;
import cn.enilu.flash.dao.message.MessagetemplateRepository;
import cn.enilu.flash.service.BaseService;
import org.springframework.stereotype.Service;
/**
 * MessagetemplateService
 *
 *@Author enilu
 * @version 2019/05/17 0017
 */
@Service
public class MessagetemplateService  extends BaseService<MessageTemplate,Long,MessagetemplateRepository> {

}

