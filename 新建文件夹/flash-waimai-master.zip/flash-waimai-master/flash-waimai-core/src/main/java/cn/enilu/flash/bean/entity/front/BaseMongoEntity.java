package cn.enilu.flash.bean.entity.front;

import javax.persistence.MappedSuperclass;

/**
 * @author ：enilu
 * @date ：Created in 2019/9/4 14:31
 */
@MappedSuperclass
public class BaseMongoEntity     {

}
