'use strict'
module.exports = {
  NODE_ENV: '"uat"',
  BASE_API: '"http://waimai-api.microapp.store/api"',
}
