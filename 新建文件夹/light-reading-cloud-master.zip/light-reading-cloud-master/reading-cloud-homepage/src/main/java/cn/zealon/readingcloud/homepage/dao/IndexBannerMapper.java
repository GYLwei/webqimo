package cn.zealon.readingcloud.homepage.dao;

import cn.zealon.readingcloud.common.pojo.index.IndexBanner;

/**
 * Banner
 * @author: zealon
 * @since: 2020/4/6
 */
public interface IndexBannerMapper {

    IndexBanner selectById(Integer id);

}
