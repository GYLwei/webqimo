package cn.zealon.readingcloud.homepage.common;

/**
 * 主页常量
 * @author: zealon
 * @since: 2020/4/7
 */
public class Const {

    /** 随机书单的次数 */
    public static final Integer BOOKLIST_RANDOM_COUNT = 7;
}
