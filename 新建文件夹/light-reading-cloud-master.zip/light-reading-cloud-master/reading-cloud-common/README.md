# spring-cloud-quick-start
公用jar包：存放实体类、工具类等。

1.公共缓存Key，为什么不使用一个，而是多个
2.RedisService 定义在common的好处
3.pojo的好处，为什么分包，分库